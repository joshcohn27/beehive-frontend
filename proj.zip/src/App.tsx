import { JSX, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { Header } from './components/Header'
import { LoginPage } from './pages/LoginPage'
import { Routes, Route, Navigate } from "react-router-dom";
import { DashboardPage } from './pages/DashboardPage'

// import './App.css'
import { Footer } from './components/Footer'
import { useAuthStore, isAuthenticated } from './utils/AuthStore';
import { DataPage } from './pages/DataPage'
import { SensorType } from './types/SensorTypeEnums'
import { LandingPage } from './pages/LandingPage'
import { RegisterPage } from './pages/RegisterPage'
import GraphPage from './pages/GraphPage'
import { SettingsPage } from './pages/SettingsPage'
import { InspectionPage } from './pages/InspectionPage'
import { ObservationPage } from './pages/ObservationPage'

function App() {

    const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
      const user = useAuthStore((s) => s.user);
      const expiresAt = useAuthStore((s) => s.expiresAt);
      const isAuth = !!user && (!expiresAt || Date.now() < expiresAt);

      return isAuth ? children : <Navigate to="/landing" replace />;
    };

    const PublicOnlyRoute = ({ children }: { children: JSX.Element }) => {
      const user = useAuthStore((s) => s.user);
      const expiresAt = useAuthStore((s) => s.expiresAt);

      const isAuth = !!user && (!expiresAt || Date.now() < expiresAt);

      return isAuth ? <Navigate to="/dashboard" replace /> : children;
    };

    const RootRedirect = () => {
      const user = useAuthStore((s) => s.user);
      const expiresAt = useAuthStore((s) => s.expiresAt);
      const isAuth = !!user && (!expiresAt || Date.now() < expiresAt);

      return isAuth ? <Navigate to="/dashboard" replace /> : <Navigate to="/landing" replace />;
    };

    return (
      <>
        <Header />
          <Routes>
            <Route path="/" element={<RootRedirect />} />
            <Route path="/landing" element={<PublicOnlyRoute><LandingPage /></PublicOnlyRoute>} />
            <Route path="/register" element={<PublicOnlyRoute><RegisterPage /></PublicOnlyRoute>} />
            <Route path="/login" element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} />

            <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/SettingsPage" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
            <Route path="/Temperature/:id" element={<ProtectedRoute><DataPage sensorType={SensorType.TEMPERATURE} /></ProtectedRoute>} />
            <Route path="/Humidity/:id" element={<ProtectedRoute><DataPage sensorType={SensorType.HUMIDITY} /></ProtectedRoute>} />
            <Route path="/CarbonDioxide/:id" element={<ProtectedRoute><DataPage sensorType={SensorType.CARBON_DIOXIDE} /></ProtectedRoute>} />
            <Route path="/Weight/:id" element={<ProtectedRoute><DataPage sensorType={SensorType.WEIGHT} /></ProtectedRoute>} />
            <Route path="/Volume/:id" element={<ProtectedRoute><DataPage sensorType={SensorType.VOLUME} /></ProtectedRoute>} />
            <Route path="/inspections/:id" element={<ProtectedRoute><InspectionPage /></ProtectedRoute>} />
            <Route path="/observations/:id" element={<ProtectedRoute><ObservationPage /></ProtectedRoute>} />
          </Routes>
        <Footer />
      </>
    )
}

export default App
