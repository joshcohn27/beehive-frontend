
/*
    API handling function ex.

        try {
            const created = await fetchJson("/api/login", {
                method: "POST",
                credentials: "include",
                body: { username: username, password: password },
            });

        } catch (e) {

            if (e instanceof ApiError){
                setError(`${e.status}: ${e.message}`)
            } else {
                setError("Unexpected error")
            };
        }
*/

import { getToken } from "./AuthStore";


export class ApiError extends Error {
  status: number;
  url: string;
  body?: unknown;

  constructor(message: string, args: { status: number; url: string; body?: unknown }) {
    super(message);
    this.name = "ApiError";
    this.status = args.status;
    this.url = args.url;
    this.body = args.body;
  }
}

type FetchJsonOptions = Omit<RequestInit, "body"> & {
  body?: unknown;          // allow passing objects; we JSON.stringify automatically
  timeoutMs?: number;      // optional timeout
  baseUrl?: string;        // optional base URL (e.g., from env)
};

export async function fetchJson<T>(
  pathOrUrl: string,
  options: FetchJsonOptions = {}
): Promise<T> {
  const {
    timeoutMs = 15000,
    baseUrl,
    headers,
    body,
    ...init
  } = options;
const apiBase = import.meta.env.VITE_API_URL ?? "/api";

const url = pathOrUrl.startsWith("http")
  ? pathOrUrl
  : `${apiBase.replace(/\/$/, "")}/${pathOrUrl.replace(/^\//, "")}`;


  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      ...init,
      headers: {
        Authorization: `Bearer ${getToken() ?? ""}`,
        Accept: "application/json",
        ...(body != null ? { "Content-Type": "application/json" } : {}),
        ...(headers ?? {}),
      },
      body: body != null ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });


    const contentType = res.headers.get("content-type") ?? "";
    const isJson = contentType.includes("application/json");

    const parsedBody = isJson ? await res.json().catch(() => undefined) : await res.text().catch(() => undefined);

    if (!res.ok) {
      const msg =
        typeof parsedBody === "string"
          ? parsedBody
          : (parsedBody as any)?.message || `Request failed (${res.status})`;
      throw new ApiError(msg, { status: res.status, url, body: parsedBody });
    }

    return parsedBody as T;
  } finally {
    window.clearTimeout(timer);
  }
}
