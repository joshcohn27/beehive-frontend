import { create } from "zustand";
import { persist } from "zustand/middleware";

export type SessionUser = {
    token?: string;
    userID?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    organizationID?: string;
    phone?: string;
    notificationParams?: {
        Death_Notify_Email?: boolean;
        Death_Notify_Phone?: boolean;
        Death_Notify_Application?: boolean;
        Swarm_Notify_Email?: boolean;
        Swarm_Notify_Phone?: boolean;
        Swarm_Notify_Application?: boolean;
        Cleansing_Flight_Notify_Email?: boolean;
        Cleansing_Flight_Notify_Phone?: boolean;
        Cleansing_Flight_Notify_Application?: boolean;
    }
};

type AuthState = {
  user: SessionUser | null;
  expiresAt: number | null;

  setUser: (user: SessionUser | null) => void;
  setExpiresAt: (expiresAt: number | null) => void;
};

// What we actually persist in localStorage
type PersistedAuthState = {
  user: SessionUser | null;
  expiresAt: number | null;
};

export const useAuthStore = create<AuthState>()(
    persist(
        (set) => ({
        user: null,
        expiresAt: null,

        setUser: (user) => set({ user }),
        setExpiresAt: (expiresAt) => set({ expiresAt }),
        }),
        {
        name: "app_session",
        partialize: (state): PersistedAuthState => ({
            user: state.user,
            expiresAt: state.expiresAt,
        }),
        }
    )
);

// login function
export const setLogin = (user: SessionUser, ttlMs = 60 * 60 * 1000) => {
    useAuthStore.getState().setUser(user);
    useAuthStore.getState().setExpiresAt(Date.now() + ttlMs);
};

export const getUser = (): SessionUser | null => {
    const state = useAuthStore.getState();
    if (!state.user) return null;
    if (state.expiresAt && Date.now() >= state.expiresAt) {
        setLogout(); // auto-logout on expiry
        return null;
    }
    return state.user;
}

export const getToken = (): string | null => {
    const user = getUser();
    return user?.token || null;
}

// logout function
export const setLogout = () => {
    useAuthStore.getState().setUser(null);
    useAuthStore.getState().setExpiresAt(null);
};

// isAuthenticated helper
export const isAuthenticated = (): boolean => {
    const state = useAuthStore.getState();
    if (!state.user) return false;
    if (state.expiresAt && Date.now() >= state.expiresAt) {
        setLogout(); // auto-logout on expiry
        return false;
    }
    return true;
};
